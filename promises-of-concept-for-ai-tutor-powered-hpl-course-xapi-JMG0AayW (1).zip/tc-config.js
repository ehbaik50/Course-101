/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
TC_COURSE_ID = "http://Oc2fcu1kOnblZoBu_0GcudpnLtLjd1lB_rise"

//
// CourseName for the activity
//
TC_COURSE_NAME = {
  "en-US": "Promises of Concept for AI-Tutor Powered HPL Course"
};

//
// CourseDesc for the activity
//
TC_COURSE_DESC = {
  "en-US": "&lt;p&gt;The advent of Large Language Models (LLMs) like ChatGPT, Ving, Bard, and Claude, with their capacity for generating expansive, human-like text, has ushered in new prospects for personalized learning. It also raises important questions regarding the evolving role of teachers. Personalized learning is expected to boost student engagement, motivation, and outcomes by delivering an educational experience tailored to the unique learning trajectories of each student. Integrating AI-tutor assistance into HPL online course demands a multifaceted approach. Aimed at developing a prototype for an AI-tutor driven HPL course, this project delves into previous user experiences. It aims to reveal both functional and pedagogical benefits for students and faculty within the HPL context.&lt;/p&gt;"
};
